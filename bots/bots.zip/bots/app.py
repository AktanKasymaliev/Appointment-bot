import json

def handler(event, context):
    url = 'https://google.com'
    return url
